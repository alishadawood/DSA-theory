#include <iostream>
using namespace std;
class Employee {
public:
    string name;      
    int employeeID;    
    float basicSalary;  
    float allowances[3]; 
    Employee(string n, int id, float salary, float a[3]) {
        name = n;
        employeeID = id;
        basicSalary = salary;
        for (int i = 0; i < 3; i++) {
            allowances[i] = a[i];
        }
    }
    float calculateTotalEarnings() {
        float totalEarnings = basicSalary;
        for (int i = 0; i < 3; i++) {
            totalEarnings += allowances[i]; 
        }
        return totalEarnings;
    }
    void display() {
        cout << "Name: " << name << "\n";
        cout << "Employee ID: " << employeeID << "\n";
        cout << "Basic Salary: " << basicSalary << "\n";
        cout << "Quarterly Allowances: " << allowances[0] << ", " << allowances[1] << ", " << allowances[2] << "\n";
        cout << "Total Earnings: " << calculateTotalEarnings() << "\n\n";
    }
    ~Employee() {
        cout << "Employee " << name << " record deleted.\n";
    }
};
int main() {
    int numEmployees;
    cout << "Enter number of employees: ";
    cin >> numEmployees;
    Employee** employees = new Employee*[numEmployees];
    for (int i = 0; i < numEmployees; i++) {
        string name;
        int id;
        float salary, allowances[3];
        cout << "Enter details for Employee " << i + 1 << ":\n";
        cout << "Name: ";
        cin >> name;
        cout << "Employee ID: ";
        cin >> id;
        cout << "Basic Salary: ";
        cin >> salary;
        cout << "Enter Quarterly Allowances (3 values): ";
        for (int j = 0; j < 3; j++) {
            cin >> allowances[j];
        }
        employees[i] = new Employee(name, id, salary, allowances);
    }
    cout << "\nEmployee Details:\n";
    for (int i = 0; i < numEmployees; i++) {
        employees[i]->display();
    }
    for (int i = 0; i < numEmployees; i++) {
        delete employees[i];
    }
    delete[] employees; 
    return 0;
}

