#include <iostream>
using namespace std;

class Product {
private:
    int productID;
    string name;
    float price;
    int stockQuantity;

public:
    // Constructor
    Product(int id, string n, float p, int s) {
        productID = id;
        name = n;
        price = p;
        stockQuantity = s;
    }

    // Destructor
    ~Product() {
        cout << "Product \"" << name << "\" deleted.\n";
    }

    // Display function
    void display() {
        cout << "ID: " << productID << "\n"
             << "Name: " << name << "\n"
             << "Price: $" << price << "\n"
             << "Stock: " << stockQuantity << "\n";
        if (stockQuantity < 5) {
            cout << "Warning: Low stock!\n";
        }
        cout << "----------------------\n";
    }

    // Update stock when sold
    void sellProduct(int quantity) {
        if (quantity > stockQuantity) {
            cout << "Not enough stock available!\n";
        } else {
            stockQuantity -= quantity;
            cout << quantity << " items sold.\n";
        }
    }
};

int main() {
    int size;
    cout << "Enter number of products: ";
    cin >> size;
    cin.ignore(); // Clear newline character

    // Dynamic array of products
    Product* inventory[size];

    // Adding products
    for (int i = 0; i < size; i++) {
        int id, stock;
        float price;
        string name;

        cout << "Enter Product ID: ";
        cin >> id;
        cin.ignore(); // Clear input buffer
        cout << "Enter Product Name: ";
        getline(cin, name);
        cout << "Enter Price: ";
        cin >> price;
        cout << "Enter Stock Quantity: ";
        cin >> stock;

        inventory[i] = new Product(id, name, price, stock);
        cout << "Product added successfully!\n";
        cout << "----------------------\n";
    }

    // Displaying products
    cout << "\nProduct Inventory:\n";
    for (int i = 0; i < size; i++) {
        inventory[i]->display();
    }

    // Selling a product
    int pid, qty;
    cout << "\nEnter product index to sell from (0 to " << size - 1 << "): ";
    cin >> pid;
    cout << "Enter quantity to sell: ";
    cin >> qty;
    
    if (pid >= 0 && pid < size) {
        inventory[pid]->sellProduct(qty);
        inventory[pid]->display();
    } else {
        cout << "Invalid product index!\n";
    }

    // Deleting dynamically allocated products
    for (int i = 0; i < size; i++) {
        delete inventory[i];
    }

    return 0;
}

