#include <iostream>

using namespace std;

class Book {
public:
    string title, author, ISBN;
    int availableCopies;

    Book(string t, string a, string i, int c) {
        title = t;
        author = a;
        ISBN = i;
        availableCopies = c;
    }

    void display() {
        cout << "Title: " << title << ", Author: " << author 
             << ", ISBN: " << ISBN << ", Available: " << availableCopies << endl;
    }
};

Book** library; 
int totalBooks = 0, maxBooks = 0; 

void addBook() {
    if (totalBooks >= maxBooks) {
        cout << "Library is full!\n";
        return;
    }

    string title, author, ISBN;
    int copies;
    cout << "Enter Title: "; 
	cin.ignore(); 
	getline(cin, title);
    cout << "Enter Author: ";
	 getline(cin, author);
    cout << "Enter ISBN: ";
	 cin >> ISBN;
    cout << "Enter Available Copies: "; 
	cin >> copies;

    library[totalBooks++] = new Book(title, author, ISBN, copies);
    cout << "Book added successfully!\n";
}

void searchBook() {
    string keyword;
    cout << "Enter Title or Author to Search: "; 
	cin.ignore(); 
	getline(cin, keyword);

    for (int i = 0; i < totalBooks; i++) {
        if (library[i]->title == keyword || library[i]->author == keyword) {
            library[i]->display();
            return;
        }
    }
    cout << "Book not found!\n";
}

void issueBook() {
    string isbn;
    cout << "Enter ISBN of Book to Issue: ";
	 cin >> isbn;

    for (int i = 0; i < totalBooks; i++) {
        if (library[i]->ISBN == isbn && library[i]->availableCopies > 0) {
            library[i]->availableCopies--;
            cout << "Book issued successfully!\n";
            return;
        }
    }
    cout << "Book not available!\n";
}

void returnBook() {
    string isbn;
    cout << "Enter ISBN of Book to Return: "; cin >> isbn;

    for (int i = 0; i < totalBooks; i++) {
        if (library[i]->ISBN == isbn) {
            library[i]->availableCopies++;
            cout << "Book returned successfully!\n";
            return;
        }
    }
    cout << "Invalid ISBN!\n";
}

void displayBooks() {
    if (totalBooks == 0) {
        cout << "No books available!\n";
        return;
    }
    for (int i = 0; i < totalBooks; i++) {
        library[i]->display();
    }
}

void deleteAllBooks() {
    for (int i = 0; i < totalBooks; i++) {
        delete library[i];
    }
    delete[] library;
    totalBooks = 0;
}

int main() {
    cout << "Enter how many types of books you want to store in the library: ";
    cin >> maxBooks;

    library = new Book*[maxBooks]; 

    int choice;
    do {
        cout << "\nLibrary Menu:\n";
        cout << "1. Add Book\n2. Search Book\n3. Issue Book\n4. Return Book\n5. Display Books\n6. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
			 addBook();
			  break;
            case 2: 
			searchBook(); 
			break;
            case 3:
			 issueBook();
			  break;
            case 4:
			 returnBook();
			  break;
            case 5:
			 displayBooks();
			  break;
            case 6:
			 deleteAllBooks();
			  cout << "Exiting...\n"; 
			  break;
            default: 
			cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 6);

    return 0;
}

