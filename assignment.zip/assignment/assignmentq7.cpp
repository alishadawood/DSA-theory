#include <iostream>
using namespace std;
class Car {
public:
    string brand, model;
    float price;
    Car(string b, string m, float p) {
        brand = b;
        model = m;
        price = p;
    }
    void display() {
        cout << "Brand: " << brand << ", Model: " << model << ", Price: $" << price << endl;
    }
    ~Car() {
        cout << "Car " << brand << " " << model << " removed from inventory.\n";
    }
};
int main() {
    int size;
    cout << "Enter number of cars: ";
    cin >> size;
    Car* showroom[size]; 
    for (int i = 0; i < size; i++) {
        string brand, model;
        float price;

        cout << "Enter Brand: ";
        cin >> brand;
        cout << "Enter Model: ";
        cin >> model;
        cout << "Enter Price: ";
        cin >> price;

        showroom[i] = new Car(brand, model, price);  
    }
    int choice;
    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Display Cars\n2. Sell a Car\n3. Search by Brand\n4. Exit\nEnter choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                cout << "\nAvailable Cars:\n";
                for (int i = 0; i < size; i++) {
                    if (showroom[i]) showroom[i]->display();
                }
                break;
            }
            case 2: {
                int sellIndex;
                cout << "Enter car index to sell (1 to " << size << "): ";
                cin >> sellIndex;
                
                if (sellIndex < 1 || sellIndex > size || showroom[sellIndex - 1] == NULL) {
                    cout << "Invalid selection!\n";
                } else {
                    delete showroom[sellIndex - 1];  
                    showroom[sellIndex - 1] = NULL;  
                    cout << "Car sold!\n";
                }
                break;
            }
            case 3: {
                string searchBrand;
                cout << "Enter Brand to search: ";
                cin >> searchBrand;
                bool found = false;
                for (int i = 0; i < size; i++) {
                    if (showroom[i] && showroom[i]->brand == searchBrand) {
                        showroom[i]->display();
                        found = true;
                    }
                }
                if (!found) cout << "No car found for this brand!\n";
                break;
            }
            case 4: {
                for (int i = 0; i < size; i++) {
                    if (showroom[i]) delete showroom[i];
                }
                cout << "Exiting Program...\n";
                return 0; 
            }
            default:
                cout << "Invalid Choice!\n";
        }
    }
    return 0;
}

