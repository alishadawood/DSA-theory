#include <iostream>
using namespace std;
class Vehicle {
public:
    string regNumber;
    int slot;
    Vehicle(string reg, int s) {
        regNumber = reg;
        slot = s;
    }
    ~Vehicle() {
        cout << "Vehicle with Reg# " << regNumber << " removed from slot " << slot << ".\n";
    }
    void display() {
        cout << "Slot " << slot << ": " << regNumber << "\n";
    }
};
int main() {
    int size;
    cout << "Enter total parking slots: ";
    cin >> size;

    Vehicle* parking[size] = {NULL}; 
    while (true) {
        cout << "\n1. Add Vehicle\n2. Remove Vehicle\n3. Show Available Slots\n4. Exit\n";
        cout << "Enter choice: ";
        int choice;
        cin >> choice;

        if (choice == 1) {
            string reg;
            int slot = -1;
            for (int i = 0; i < size; i++) {
                if (parking[i] == NULL ) {
                    slot = i + 1;
                    break;
                }
            }
            if (slot == -1) {
                cout << "Parking Full!\n";
            } else {
                cout << "Enter Registration Number: ";
                cin >> reg;
                parking[slot - 1] = new Vehicle(reg, slot);
                cout << "Vehicle Parked at Slot " << slot << ".\n";
            }
        } 
        else if (choice == 2) {
            int slot;
            cout << "Enter Slot Number to remove: ";
            cin >> slot;
            if (slot < 1 || slot > size || parking[slot - 1] == NULL) {
                cout << "Invalid slot or already empty!\n";
            } else {
                delete parking[slot - 1]; 
                parking[slot - 1] = NULL;
            }
        } 
        else if (choice == 3) { 
            cout << "Available Slots: ";
            bool found = false;
            for (int i = 0; i < size; i++) {
                if (parking[i] == NULL) {
                    cout << (i + 1) << " ";
                    found = true;
                }
            }
            if (!found) cout << "None";
            cout << "\n";
        } 
        else if (choice == 4) { 
            for (int i = 0; i < size; i++) {
                if (parking[i]) {
                    delete parking[i]; 
                }
            }
            cout << "Exiting Program...\n";
            break;
        } 
        else {
            cout << "Invalid choice! Try again.\n";
        }
    }
    return 0;
}

