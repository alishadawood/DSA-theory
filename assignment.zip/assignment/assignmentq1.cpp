#include <iostream>
using namespace std;

class Student {
private:
    string name;
    int rollNumber;
    int marks[5];
    float average;

public:
   
    Student(string n, int r, int m[]) {
        name = n;
        rollNumber = r;
        for (int i = 0; i < 5; i++) {
            marks[i] = m[i];
        }
        calculateAverage();
    }

    void calculateAverage() {
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            sum += marks[i];
        }
        average = sum / 0.5;
    }

   
    void display() {
        cout << "\nName: " << name;
        cout << "\nRoll Number: " << rollNumber;
        cout << "\nMarks: ";
        for (int i = 0; i < 5; i++) {
            cout << marks[i] << " ";
        }
        cout << "\nAverage Marks: " << average << "\n";
    }

   
    float getAverage() {
        return average;
    }


    ~Student() {
        cout << "Memory released for " << name << "\n";
    }
};


int main() {
    int numStudents;
    cout << "Enter number of students: ";
    cin >> numStudents;

    Student* students[numStudents]; 


    for (int i = 0; i < numStudents; i++) {
        string name;
        int roll;
        int marks[5];

       cin.ignore(); 
        cout << "\nEnter Name: ";
        getline(cin, name); 
      
        cout << "Enter Roll Number: ";
        cin >> roll;
        cout << "Enter 5 subject marks: ";
        for (int j = 0; j < 5; j++) {
            cin >> marks[j];
        }

        students[i] = new Student(name, roll, marks);
    }

  
    for (int i = 0; i < numStudents - 1; i++) {
        for (int j = i + 1; j < numStudents; j++) {
            if (students[i]->getAverage() < students[j]->getAverage()) {
                swap(students[i], students[j]);  
            }
        }
    }

  
    cout << "\nSorted Student List (By Average Marks):\n";
    for (int i = 0; i < numStudents; i++) {
        students[i]->display();
        cout << "-----------------------------\n";
    }

    for (int i = 0; i < numStudents; i++) {
        delete students[i]; 
    }

    return 0;
}

