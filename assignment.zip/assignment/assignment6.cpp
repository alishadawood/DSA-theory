#include <iostream>
using namespace std;
class Ticket {
public:
    string passengerName;
    int trainNumber;
    int seatNumber;
    bool isBooked;
    
    Ticket() {
        isBooked = false;
    }
    void bookTicket(string name, int trainNum, int seatNum) {
        passengerName = name;
        trainNumber = trainNum;
        seatNumber = seatNum;
        isBooked = true;
        cout << "Ticket booked successfully!\n";
    }
    
    void cancelTicket() {
        isBooked = false;
        cout << "Ticket canceled successfully!\n";
    }
    
    void displayTicket() {
        if (isBooked) {
            cout << "Passenger Name: " << passengerName 
                 << ", Train Number: " << trainNumber 
                 << ", Seat Number: " << seatNumber << endl;
        }
    }
};

Ticket** tickets; 
int totalSeats = 0, maxSeats = 0;

void reserveTicket() {
    if (totalSeats >= maxSeats) {
        cout << "All seats are booked!\n";
        return;
    }
    
    string name;
    int trainNum, seatNum;
    cout << "Enter Passenger Name: ";
    cin.ignore();
    getline(cin, name);
    cout << "Enter Train Number: ";
    cin >> trainNum;
    cout << "Enter Seat Number (1-" << maxSeats << "): ";
    cin >> seatNum;
    
    if (seatNum < 1 || seatNum > maxSeats || tickets[seatNum - 1]->isBooked) {
        cout << "Seat is already booked !\n";
    } else {
        tickets[seatNum - 1]->bookTicket(name, trainNum, seatNum);
        totalSeats++;
    }
}

void cancelTicket() {
    int seatNum;
    cout << "Enter Seat Number to Cancel: ";
    cin >> seatNum;
    
    if (seatNum < 1 || seatNum > maxSeats || !tickets[seatNum - 1]->isBooked) {
        cout << "No booking found for this seat!\n";
    } else {
        tickets[seatNum - 1]->cancelTicket();
        totalSeats--;
    }
}

void displayReservedTickets() {
    if (totalSeats == 0) {
        cout << "No tickets reserved!\n";
        return;
    }
    for (int i = 0; i < maxSeats; i++) {
        tickets[i]->displayTicket();
    }
}

void deleteAllTickets() {
    for (int i = 0; i < maxSeats; i++) {
        delete tickets[i];
    }
    delete[] tickets;
    totalSeats = 0;
}

int main() {
    cout << "Enter the total number of seats available: ";
    cin >> maxSeats;
    tickets = new Ticket*[maxSeats];
    for (int i = 0; i < maxSeats; i++) {
        tickets[i] = new Ticket();
    }
    
    int choice;
    do {
        cout << "\nTrain Ticket Booking System:\n";
        cout << "1. Reserve Ticket\n2. Cancel Ticket\n3. Display Reserved Tickets\n4. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        
        switch (choice) {
            case 1:
			 reserveTicket(); 
			 break;
            case 2: 
			cancelTicket();
			 break;
            case 3: 
			displayReservedTickets(); 
			break;
            case 4: 
			deleteAllTickets(); 
			cout << "Exiting...\n";
			 break;
            default: 
			cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 4);
    
    return 0;
}

